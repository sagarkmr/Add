﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplicationAddOperation.Models;

namespace MvcApplicationAddOperation.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        [HttpGet]
        public ActionResult AddOperation()
        {
            return View();
        } 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddOperation(AdditionViewModel model, string button)
        {
            if (button == "Clear")
            {
                ModelState.Clear();
                return View();
            }
            else if (button == "Add")
            {
                model.Result = model.A + model.B;
                return View(model);
            }
            return View();
        }
    }
}
